<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'u979946632_coordinacionTS');
define('DB_PASS', 'KcNt18092023');
define('DB_NAME', 'u979946632_t_soft');
?>